"""Defines all the exceptions used on UI"""

class SavedGameException(Exception):
    """Exception raised when the game has to close and save"""

class RetryGameException(Exception):
    """Exception raised when the game has to close and save"""
